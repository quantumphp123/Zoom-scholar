<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Laravel\Cashier\Cashier;
use \Stripe\Stripe;
class SubscriptionController extends Controller
{
    public function Pay(Type $var = null)
    {
        $user=auth()->user();
        $intent=$user->createSetupIntent();
        return view('Pay',compact('intent'));
    }

    public function singleCharge(request $req)
    {
        $amount=100*100;
        $payment_method=$req->payment_method;
        //dd($req->all());
        $user=auth()->user();
        $user->createOrGetStripeCustomer();
        $payment_method=$user->addPaymentMethod($payment_method);
        $user->charge($amount,$payment_method->id,['off_session' => true]);
        return back();
    }
}
