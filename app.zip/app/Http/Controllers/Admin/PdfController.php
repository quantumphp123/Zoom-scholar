<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Professional;
use PDF;

class PdfController extends Controller
{

public function ProfessionalDetail($id)
{

    $professional=Professional::with(['skills'])->find($id);
    $pdf=PDF::loadview('Pdf.Details',compact('professional'));
    return $pdf->download('professional_details.pdf');

    //return view('Pdf.Details', compact('professional','skills','images'));
}

}
