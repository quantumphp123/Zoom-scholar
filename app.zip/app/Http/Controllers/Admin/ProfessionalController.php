<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Professional;
use App\Models\Skill;
use App\Models\ProfessionalSkill;
use App\Models\Image;
use App\Mail\RegsitrationMail;
use Mail;
use PDF;

class ProfessionalController extends Controller
{

    public function masterdata()
    {
        $skills=Skill::where('status',1)->pluck('name','id');

          return $skills;
    }


    public function Index(Type $var = null)
    {
        $professionals=Professional::latest()->get();
        //dd($professionals);
        return view('Professionals.index',compact('professionals'));
    }

    public function add()
    {
        $skills=$this->masterdata();
        //dd($skills);
        return view('Professionals.Create', compact('skills'));
    }

    public function Create(request $req)
    {

        //$validatedData=$req->validate([
        //    'email' =>'required',
        //    'name'=>'required',
        //    'address'=>'required',
        //    //'role'=>'required',
        //    'image'=>['required','image','mimes:jpg,png,jpeg,gif'],
//
        //    ]);
        //dd($req->all());
        $professional=new Professional;
        $professional->name=$req->name;
        $professional->email=$req->email;
        $professional->mobile=$req->mobile;
        $professional->address=$req->address;
       if ($req->image) {
        $imagename = time().'-'.".".$req->image->extension();
        //dd($imagename);
        $dest_path='public/images/Professionals';
        //$imagename = time().'-'.".".$req->logo->extension();
        $req->image->storeAs($dest_path, $imagename) ;
        $professional->image=$imagename;
       }

        $professional->save();
        $details=[ 'title' => 'Registration mail',
        'body' => 'welcome to adminlte3' .$req->name];
        Mail::to($req->email)->send(new RegsitrationMail($details));
        $skillids=$req->skill;
        $professional->skills()->attach($skillids);

        return redirect()->route('professional.index')->with('insert','professional inserted');

    }

    public function Detail($id)
    {
        $professional=Professional::with(['skills'])->find($id);
        $skills=$this->masterdata();
        $images=Image::where('user_id',$id)->get(['image','status','id']);
       // dd( $professional);
        return view('Professionals.Details', compact('professional','skills','images'));
    }

    public function Delete($id)
    {
        $professional=Professional::with(['skills'])->find($id);
        if ( $professional->image) {


            $dest=public_path()."\storage/images/Professionals"."/".basename($professional->image);
            unlink($dest);
        }
        $professional->delete();
        $professional->skills()->detach();
        return back()->with('delete', 'Profile has been deleted!');
    }

    public function update(request $req)
    {
          //$validatedData=$req->validate([
        //    'email' =>'required',
        //    'name'=>'required',
        //    'address'=>'required',
        //    'role'=>'required',
        //    'image'=>['required','image','mimes:jpg,png,jpeg,gif'],
//
        //    ]);
        //dd($req->all());

        $professional=Professional::find($req->id);
        $professional->name=$req->name;
        $professional->email=$req->email;
         $professional->mobile=$req->mobile;
        $professional->address=$req->address;
        $professional->update();

        return back()->with('update', 'Profile has been updated!');


    }

    public function update_status(request $req)
    {
        $professional=Professional::find($req->user_id);
         $professional->status=$req->status;
         $professional->save();
         //return response($status);

    }

    public function add_skill(request $req)
    {
        $professional=Professional::find($req->id);
        $skillids=$req->skill;
        $professional->skills()->attach($skillids);
        return back()->with('insert','skill added');

    }
    public function Delete_skill($professional_id,$skill_id)
    {

        $professional=Professional::find($professional_id);

        $professional->skills()->detach($skill_id);
        return back()->with('delete','skill deleted');

    }
       public function upload_images(request $req)
       {
        //dd($req->all());

        foreach($req->file('image') as $key=> $file)
        {
            $name = time().$key.'.'.$file->extension();
            $dest_path='public/images/Professionals';
            $file->storeAs($dest_path, $name) ;
            $data[] = $name;
        }
        //dd($data);

        for ($i=0; $i <count($data) ; $i++) {
            $image=new Image;
            $image->image=$data[$i];
            $image->user_id=$req->id;
            $image->save();

        }

        return back()->with('insert', 'image has been uploaded!');



       }

       public function Image_status(request $req)
       {
        $image=Image::find($req->user_id);
        $status =0;
        if ($image->status == 0) {
            $status =1;
         }

         $image->status=$status;
         $image->save();
         return response($status);
       }

       public function Delete_image($id)
       {

        $image=Image::find($id);

        $dest=public_path()."\storage/images/Professionals"."/".basename($image->image);
        unlink($dest);
        $image->delete();
        return back()->with('delete', 'Image has been deleted!');

       }


//public function pdf_data()
//{
//    $data=Professional::all();
//
//    return view('Pdf',compact('data'));
//}

      public function export()
      {
          $data=Professional::all();
          $pdf=PDF::loadview('pdf',compact('data'));
          return $pdf->download('professional.pdf');
      }

}
