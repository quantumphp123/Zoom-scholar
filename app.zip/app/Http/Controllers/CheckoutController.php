<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Stripe;
class CheckoutController extends Controller
{
    public function checkout(request $req)
{

    \Stripe\Stripe::setApiKey('sk_test_51LG4ekSEkbbVCV9Qb1Qp2oJEjh7eM7MCHFWamtyysP88TwdxGq5jKwd4KdFRltac5zAlKtyQDCQyEA0GTVuU2OSw00f0lPk73n');


    $amount = $req->amount;
    $amount *= 100;
    $amount = (int) $amount;
    $customer = \Stripe\Customer::create([
        'name' => 'test',
        'description' => 'test customer description',
        'address' => [
            'line1' => '510 Townsend St',
            'postal_code' => '98140',
            'city' => 'San Francisco',
            'state' => 'CA',
            'country' => 'US',
          ]
    ]);



    $payment_intent = \Stripe\PaymentIntent::create([
        'description' => 'Stripe Test Payment',
        'amount' => $amount,
        'currency' => 'inr',
        'description' => 'Payment From ',
        'payment_method_types' => ['card'],
        'customer'=>$customer->id
    ]);

    $intent = $payment_intent->client_secret;
    $stripe = new \Stripe\StripeClient(
        'sk_test_51LG4ekSEkbbVCV9Qb1Qp2oJEjh7eM7MCHFWamtyysP88TwdxGq5jKwd4KdFRltac5zAlKtyQDCQyEA0GTVuU2OSw00f0lPk73n'
      );
     $data= $stripe->tokens->create([
        'card' => [
          'number' => '4242424242424242',
          'exp_month' => 8,
          'exp_year' => 2023,
          'cvc' => '314',
        ],
      ]);

      $token = $data->id;

 Stripe\Stripe::setApiKey('sk_test_51LG4ekSEkbbVCV9Qb1Qp2oJEjh7eM7MCHFWamtyysP88TwdxGq5jKwd4KdFRltac5zAlKtyQDCQyEA0GTVuU2OSw00f0lPk73n');
     Stripe\Charge::create ([
             "amount" => 100 * 100,
             "currency" => "inr",
             "source" => $token,
             "description" => "This payment is tested purpose phpcodingstuff.com"
     ]);






         return response()->json([
            'responseCode' => 200,
            'client secret' => $token,
        ]);



}


    public function afterPayment()
    {
        echo 'Payment Received, Thanks you for using our services.';
    }
}
